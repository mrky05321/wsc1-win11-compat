﻿# WSC1 Windows 11 Compatibility

PC版初代『鋼鉄の咆哮』向けの非公式互換DLLです。描画変換には未改変のdxwrapper v1.8.8600.25を使用し、ゲーム内の小窓の位置とCD音声再生を補正します。

配布パッケージ **v0.3.2**。小窓・BGM補正を引き継ぎ、専用DLLのログ書き込み処理を削除しました。描画backendも `DisableLogging=1` を配布時の初期設定にしています。

## 導入

1. [配布ZIP v0.3.2](downloads/v0.3.2/wsc1-win11-compat-v0.3.2.zip) をダウンロードして展開します。SHA-256は同じフォルダーの `SHA256SUMS.txt` で確認できます。
2. `ddraw.dll`、`dxwrapper.dll`、`dxwrapper.ini` の**3ファイル**を `BCS.exe` と同じフォルダーへコピーします。
3. いつもどおり `BCS.exe` を起動します。初期設定は枠付きウィンドウです。

ZIP内の4つ目のファイル `README.txt` には導入手順とライセンスをまとめています。ゲームフォルダーへコピーする必要はありません。既存の同名DLLや設定を使っている場合は、先にそれらを別の場所へ退避してください。

ゲーム本体・セーブ・BGM・CDイメージは含みません。通常のゲーム起動条件は引き続き必要です。ゲームのEXE/ICDやセーブをディスク上で書き換えません。

## BGM

- ゲームのBGMはCD音声です。フォルダーに対応音源がなければ、CDドライブの再生経路を使います。ドライブ未指定の場合はボリューム名 `Kurogane` のドライブを選びます。イメージファイルの固定パスは参照しません。
- 所有ディスクから準備した `music/cd-audio.wav` と `music/cd-audio.ini` があれば、その音源を通常の音声出力で再生します。これらの音源は配布ZIPに含めません。
- 確認済み環境ではファイル音源によるBGMの出音と曲切替を確認しました。**CD直接再生の出音は未確認**のため、音源ファイルなしでも必ずBGMが鳴るという保証ではありません。
- 音源準備用の開発ツールは `tools/extract_cd_audio.py` です。Python 3.8以上で `python tools/extract_cd_audio.py <所有ディスクのcue> <ゲームフォルダー>/music` と実行します。対応形式はKuroganeの単一IMG・16トラックのCUEです。

## 表示モード

ゲームを終了して `dxwrapper.ini` の `[d3d9]` を編集し、再起動します。

| 表示 | EnableWindowMode | WindowModeBorder | FullscreenWindowMode |
|---|---:|---:|---:|
| 枠付きウィンドウ（初期設定・推奨） | 1 | 1 | 0 |
| 枠なし通常ウィンドウ（画面外の点滅報告あり） | 1 | 0 | 0 |
| ボーダレス全画面 | 0 | 0 | 1 |
| ゲーム標準 | 0 | 0 | 0 |

起動中のAlt+Enter切替には対応していません。


### ボーダーレス時の周囲の点滅

利用者動画で、640×480の枠なし通常ウィンドウ（EnableWindowMode=1, WindowModeBorder=0, FullscreenWindowMode=0）のUI変更時に、ゲーム外、特にタスクバーのアイコンが明暗を反復する現象を確認しました。ゲーム全体を全画面に拡大した状態ではありません。この現象は確認済みの正常動作には含まれず、v0.3.2でも未修正です。現在は枠付きウィンドウを推奨します。同梱版dxwrapperには画面モードの復元・破棄時にデスクトップ全体へ再描画を要求する処理がありますが、本件の実際の原因であることは未確認です。継続する点滅と、起動・モード切替時の一時的な再描画は区別します。

## 確認範囲・制限

Windows 11上の対象PC版で、タイトル・準備画面、艦船選択／兵装設定の本体内表示、「戻る」の操作、ファイル音源のBGMを確認済みです。全ミッション・全機種での動作を保証するものではありません。

専用の小窓／音声補正は `BCS.ICD` のPEタイムスタンプ `0x3855e0a2`、SizeOfImage `0x3a9000` が一致するときに有効になります。別作品や別ビルドへの互換性は未確認です。

専用DLLはログファイルを作成しません。以前の `wsc1-compat.ini` に `[Diagnostics] Enabled=1` が残っていても、専用ログの書き込みは行いません。描画backendも、同梱の `dxwrapper.ini` の `DisableLogging=1` でログを開く前に無効化しています。

小窓や音源の切替設定が必要な場合だけ、任意の `wsc1-compat.ini` を追加できます。通常導入では不要です。

```ini
[Compatibility]
Backend=dxwrapper
FixPopupCoordinates=1
DigitalCDAudio=1
```

小窓補正を止める場合は `FixPopupCoordinates=0`、音源ファイルへの切替を止める場合は `DigitalCDAudio=0` にします。

Program Files内へコピーする場合はWindowsの管理者許可が必要になることがあります。ログ作成のために管理者としてゲームを起動する必要はありません。

既存利用者はセーブ・Gnt.ini・musicフォルダーを残し、今回の更新は `ddraw.dll` を交換し、現在の `dxwrapper.ini` の `[General]` に `DisableLogging=1` を設定してください。表示モードを含む他の設定を維持する場合、配布用INIで丸ごと上書きしないでください。削除して戻す場合も、追加した互換ファイルだけを取り除きます。

## ソースからビルド

Windows、Visual Studio 2022 C++ Build Tools、Windows SDK、CMake、Python 3.8以上が必要です。ゲームは32bitのため **Win32/x86** でビルドします。

```powershell
# 専用DLLのみ（backendのダウンロードは不要）
.\build.ps1 -BuildOnly

# 上流の正規dxwrapper.zipを入手して配布用ZIPを生成
.\build.ps1 -BackendArchive 'C:\Downloads\dxwrapper.zip'
```

backendは[dxwrapper公式](https://github.com/elishacloud/dxwrapper)のv1.8.8600.25です。受け付けるarchiveのSHA-256は `3894368ebce69f348d08e189c2f0818c49aa3b18ad01e06348743bf6a29af97a`。異なるファイルは使用しません。`.cache/dxwrapper.zip` に配置して引数を省略することもできます。

`package.py` はファイル名を列挙して梱包し、ソース以外のゲームファイル・音源・セーブ・ローカルログを拾いません。生成物は `artifacts/` に出力します。ビルドやパッケージ作成によってゲームを起動したり、テストを実行したりしません。

## GitHubへの配置

このフォルダーがリポジトリのルートです。ゲームや解析データを含む親フォルダーをアップロードしないでください。

1. このフォルダーのソースをGitHubリポジトリへpushします。
2. Releasesでタグ `v0.3.2` を作成します。
3. `artifacts/wsc1-win11-compat-v0.3.2.zip` と `artifacts/SHA256SUMS.txt` を添付します。利用者にはこのZIPを案内します。

ソースZIPはバックアップ・手動アップロード用です。GitHubにソースをpush済みならReleaseへの添付は任意です。`artifacts/`、ビルド生成物やbackend DLLはGit管理対象外です。

## ライセンス

専用ソースは [MIT License](LICENSE)。backendは別ライセンスです。[THIRD_PARTY_NOTICES.txt](THIRD_PARTY_NOTICES.txt)に上流の通知全文を保持しています。配布ZIPではこれらをREADME.txtに統合しています。

同梱dxwrapperは未改変です。その対応するソースは[上流リポジトリ](https://github.com/elishacloud/dxwrapper)のv1.8.8600.25、MemoryModule部分は同リポジトリ内の対応ソースです。上流ソースと各コンポーネントにはそれぞれのライセンスが適用されます。本プロジェクトはゲーム発売元と無関係の非公式ツールです。


---
Original compatibility code license

MIT License

Copyright (c) 2026 WSC1 compatibility contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


---
Unmodified dxwrapper: complete upstream notices

License Notice
==============

This project includes code under multiple licenses.

-------------------------------------------------------------------------------
Primary Project License - dxwrapper
-------------------------------------------------------------------------------

The majority of this project, including all custom code written by Elisha
Riedlinger, is licensed as follows:

Copyright (C) 2025 Elisha Riedlinger

This software is provided 'as-is', without any express or implied warranty. In
no event will the authors be held liable for any damages arising from the use
of this software. Permission is granted to anyone to use this software for any
purpose, including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not claim
     that you wrote the original software. If you use this software in a
     product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.

-------------------------------------------------------------------------------
Third-Party Component License - d3d8to9
-------------------------------------------------------------------------------

This project incorporates code from the d3d8to9 project by Patrick Mours, used
under the following license:

Copyright (C) 2015 Patrick Mours. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  - Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.
  - Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

-------------------------------------------------------------------------------
Third-Party Component License - Detours & DirectXMath
-------------------------------------------------------------------------------

This project incorporates code from the Detours and DirectXMath projects by
Microsoft, used under the following license:

Copyright (c) Microsoft Corporation.

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

-------------------------------------------------------------------------------
Third-Party Component License - Hooking.Patterns
-------------------------------------------------------------------------------

This project incorporates code from the Hooking.Patterns project by ThirteenAG,
used under the following license:

Copyright (c) 2014 Bas Timmer/NTAuthority et al.

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

-------------------------------------------------------------------------------
Third-Party Component License - imgui
-------------------------------------------------------------------------------

This project incorporates code from the imgui project by ocornut,
used under the following license:

The MIT License (MIT)

Copyright (c) 2014-2025 Omar Cornut

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

-------------------------------------------------------------------------------
Third-Party Component License - MemoryModule
-------------------------------------------------------------------------------

This project incorporates code from the MemoryModule project by fancycode, used
under the following license:

Mozilla Public License Version 2.0
==================================

1. Definitions
--------------

1.1. "Contributor"
    means each individual or legal entity that creates, contributes to
    the creation of, or owns Covered Software.

1.2. "Contributor Version"
    means the combination of the Contributions of others (if any) used
    by a Contributor and that particular Contributor's Contribution.

1.3. "Contribution"
    means Covered Software of a particular Contributor.

1.4. "Covered Software"
    means Source Code Form to which the initial Contributor has attached
    the notice in Exhibit A, the Executable Form of such Source Code
    Form, and Modifications of such Source Code Form, in each case
    including portions thereof.

1.5. "Incompatible With Secondary Licenses"
    means

    (a) that the initial Contributor has attached the notice described
        in Exhibit B to the Covered Software; or

    (b) that the Covered Software was made available under the terms of
        version 1.1 or earlier of the License, but not also under the
        terms of a Secondary License.

1.6. "Executable Form"
    means any form of the work other than Source Code Form.

1.7. "Larger Work"
    means a work that combines Covered Software with other material, in 
    a separate file or files, that is not Covered Software.

1.8. "License"
    means this document.

1.9. "Licensable"
    means having the right to grant, to the maximum extent possible,
    whether at the time of the initial grant or subsequently, any and
    all of the rights conveyed by this License.

1.10. "Modifications"
    means any of the following:

    (a) any file in Source Code Form that results from an addition to,
        deletion from, or modification of the contents of Covered
        Software; or

    (b) any new file in Source Code Form that contains any Covered
        Software.

1.11. "Patent Claims" of a Contributor
    means any patent claim(s), including without limitation, method,
    process, and apparatus claims, in any patent Licensable by such
    Contributor that would be infringed, but for the grant of the
    License, by the making, using, selling, offering for sale, having
    made, import, or transfer of either its Contributions or its
    Contributor Version.

1.12. "Secondary License"
    means either the GNU General Public License, Version 2.0, the GNU
    Lesser General Public License, Version 2.1, the GNU Affero General
    Public License, Version 3.0, or any later versions of those
    licenses.

1.13. "Source Code Form"
    means the form of the work preferred for making modifications.

1.14. "You" (or "Your")
    means an individual or a legal entity exercising rights under this
    License. For legal entities, "You" includes any entity that
    controls, is controlled by, or is under common control with You. For
    purposes of this definition, "control" means (a) the power, direct
    or indirect, to cause the direction or management of such entity,
    whether by contract or otherwise, or (b) ownership of more than
    fifty percent (50%) of the outstanding shares or beneficial
    ownership of such entity.

2. License Grants and Conditions
--------------------------------

2.1. Grants

Each Contributor hereby grants You a world-wide, royalty-free,
non-exclusive license:

(a) under intellectual property rights (other than patent or trademark)
    Licensable by such Contributor to use, reproduce, make available,
    modify, display, perform, distribute, and otherwise exploit its
    Contributions, either on an unmodified basis, with Modifications, or
    as part of a Larger Work; and

(b) under Patent Claims of such Contributor to make, use, sell, offer
    for sale, have made, import, and otherwise transfer either its
    Contributions or its Contributor Version.

2.2. Effective Date

The licenses granted in Section 2.1 with respect to any Contribution
become effective for each Contribution on the date the Contributor first
distributes such Contribution.

2.3. Limitations on Grant Scope

The licenses granted in this Section 2 are the only rights granted under
this License. No additional rights or licenses will be implied from the
distribution or licensing of Covered Software under this License.
Notwithstanding Section 2.1(b) above, no patent license is granted by a
Contributor:

(a) for any code that a Contributor has removed from Covered Software;
    or

(b) for infringements caused by: (i) Your and any other third party's
    modifications of Covered Software, or (ii) the combination of its
    Contributions with other software (except as part of its Contributor
    Version); or

(c) under Patent Claims infringed by Covered Software in the absence of
    its Contributions.

This License does not grant any rights in the trademarks, service marks,
or logos of any Contributor (except as may be necessary to comply with
the notice requirements in Section 3.4).

2.4. Subsequent Licenses

No Contributor makes additional grants as a result of Your choice to
distribute the Covered Software under a subsequent version of this
License (see Section 10.2) or under the terms of a Secondary License (if
permitted under the terms of Section 3.3).

2.5. Representation

Each Contributor represents that the Contributor believes its
Contributions are its original creation(s) or it has sufficient rights
to grant the rights to its Contributions conveyed by this License.

2.6. Fair Use

This License is not intended to limit any rights You have under
applicable copyright doctrines of fair use, fair dealing, or other
equivalents.

2.7. Conditions

Sections 3.1, 3.2, 3.3, and 3.4 are conditions of the licenses granted
in Section 2.1.

3. Responsibilities
-------------------

3.1. Distribution of Source Form

All distribution of Covered Software in Source Code Form, including any
Modifications that You create or to which You contribute, must be under
the terms of this License. You must inform recipients that the Source
Code Form of the Covered Software is governed by the terms of this
License, and how they can obtain a copy of this License. You may not
attempt to alter or restrict the recipients' rights in the Source Code
Form.

3.2. Distribution of Executable Form

If You distribute Covered Software in Executable Form then:

(a) such Covered Software must also be made available in Source Code
    Form, as described in Section 3.1, and You must inform recipients of
    the Executable Form how they can obtain a copy of such Source Code
    Form by reasonable means in a timely manner, at a charge no more
    than the cost of distribution to the recipient; and

(b) You may distribute such Executable Form under the terms of this
    License, or sublicense it under different terms, provided that the
    license for the Executable Form does not attempt to limit or alter
    the recipients' rights in the Source Code Form under this License.

3.3. Distribution of a Larger Work

You may create and distribute a Larger Work under terms of Your choice,
provided that You also comply with the requirements of this License for
the Covered Software. If the Larger Work is a combination of Covered
Software with a work governed by one or more Secondary Licenses, and the
Covered Software is not Incompatible With Secondary Licenses, this
License permits You to additionally distribute such Covered Software
under the terms of such Secondary License(s), so that the recipient of
the Larger Work may, at their option, further distribute the Covered
Software under the terms of either this License or such Secondary
License(s).

3.4. Notices

You may not remove or alter the substance of any license notices
(including copyright notices, patent notices, disclaimers of warranty,
or limitations of liability) contained within the Source Code Form of
the Covered Software, except that You may alter any license notices to
the extent required to remedy known factual inaccuracies.

3.5. Application of Additional Terms

You may choose to offer, and to charge a fee for, warranty, support,
indemnity or liability obligations to one or more recipients of Covered
Software. However, You may do so only on Your own behalf, and not on
behalf of any Contributor. You must make it absolutely clear that any
such warranty, support, indemnity, or liability obligation is offered by
You alone, and You hereby agree to indemnify every Contributor for any
liability incurred by such Contributor as a result of warranty, support,
indemnity or liability terms You offer. You may include additional
disclaimers of warranty and limitations of liability specific to any
jurisdiction.

4. Inability to Comply Due to Statute or Regulation
---------------------------------------------------

If it is impossible for You to comply with any of the terms of this
License with respect to some or all of the Covered Software due to
statute, judicial order, or regulation then You must: (a) comply with
the terms of this License to the maximum extent possible; and (b)
describe the limitations and the code they affect. Such description must
be placed in a text file included with all distributions of the Covered
Software under this License. Except to the extent prohibited by statute
or regulation, such description must be sufficiently detailed for a
recipient of ordinary skill to be able to understand it.

5. Termination
--------------

5.1. The rights granted under this License will terminate automatically
if You fail to comply with any of its terms. However, if You become
compliant, then the rights granted under this License from a particular
Contributor are reinstated (a) provisionally, unless and until such
Contributor explicitly and finally terminates Your grants, and (b) on an
ongoing basis, if such Contributor fails to notify You of the
non-compliance by some reasonable means prior to 60 days after You have
come back into compliance. Moreover, Your grants from a particular
Contributor are reinstated on an ongoing basis if such Contributor
notifies You of the non-compliance by some reasonable means, this is the
first time You have received notice of non-compliance with this License
from such Contributor, and You become compliant prior to 30 days after
Your receipt of the notice.

5.2. If You initiate litigation against any entity by asserting a patent
infringement claim (excluding declaratory judgment actions,
counter-claims, and cross-claims) alleging that a Contributor Version
directly or indirectly infringes any patent, then the rights granted to
You by any and all Contributors for the Covered Software under Section
2.1 of this License shall terminate.

5.3. In the event of termination under Sections 5.1 or 5.2 above, all
end user license agreements (excluding distributors and resellers) which
have been validly granted by You or Your distributors under this License
prior to termination shall survive termination.

************************************************************************
*                                                                      *
*  6. Disclaimer of Warranty                                           *
*  -------------------------                                           *
*                                                                      *
*  Covered Software is provided under this License on an "as is"       *
*  basis, without warranty of any kind, either expressed, implied, or  *
*  statutory, including, without limitation, warranties that the       *
*  Covered Software is free of defects, merchantable, fit for a        *
*  particular purpose or non-infringing. The entire risk as to the     *
*  quality and performance of the Covered Software is with You.        *
*  Should any Covered Software prove defective in any respect, You     *
*  (not any Contributor) assume the cost of any necessary servicing,   *
*  repair, or correction. This disclaimer of warranty constitutes an   *
*  essential part of this License. No use of any Covered Software is   *
*  authorized under this License except under this disclaimer.         *
*                                                                      *
************************************************************************

************************************************************************
*                                                                      *
*  7. Limitation of Liability                                          *
*  --------------------------                                          *
*                                                                      *
*  Under no circumstances and under no legal theory, whether tort      *
*  (including negligence), contract, or otherwise, shall any           *
*  Contributor, or anyone who distributes Covered Software as          *
*  permitted above, be liable to You for any direct, indirect,         *
*  special, incidental, or consequential damages of any character      *
*  including, without limitation, damages for lost profits, loss of    *
*  goodwill, work stoppage, computer failure or malfunction, or any    *
*  and all other commercial damages or losses, even if such party      *
*  shall have been informed of the possibility of such damages. This   *
*  limitation of liability shall not apply to liability for death or   *
*  personal injury resulting from such party's negligence to the       *
*  extent applicable law prohibits such limitation. Some               *
*  jurisdictions do not allow the exclusion or limitation of           *
*  incidental or consequential damages, so this exclusion and          *
*  limitation may not apply to You.                                    *
*                                                                      *
************************************************************************

8. Litigation
-------------

Any litigation relating to this License may be brought only in the
courts of a jurisdiction where the defendant maintains its principal
place of business and such litigation shall be governed by laws of that
jurisdiction, without reference to its conflict-of-law provisions.
Nothing in this Section shall prevent a party's ability to bring
cross-claims or counter-claims.

9. Miscellaneous
----------------

This License represents the complete agreement concerning the subject
matter hereof. If any provision of this License is held to be
unenforceable, such provision shall be reformed only to the extent
necessary to make it enforceable. Any law or regulation which provides
that the language of a contract shall be construed against the drafter
shall not be used to construe this License against a Contributor.

10. Versions of the License
---------------------------

10.1. New Versions

Mozilla Foundation is the license steward. Except as provided in Section
10.3, no one other than the license steward has the right to modify or
publish new versions of this License. Each version will be given a
distinguishing version number.

10.2. Effect of New Versions

You may distribute the Covered Software under the terms of the version
of the License under which You originally received the Covered Software,
or under the terms of any subsequent version published by the license
steward.

10.3. Modified Versions

If you create software not governed by this License, and you want to
create a new license for such software, you may create and use a
modified version of this License if you rename the license and remove
any references to the name of the license steward (except to note that
such modified license differs from this License).

10.4. Distributing Source Code Form that is Incompatible With Secondary
Licenses

If You choose to distribute Source Code Form that is Incompatible With
Secondary Licenses under the terms of this version of the License, the
notice described in Exhibit B of this License must be attached.

Exhibit A - Source Code Form License Notice
-------------------------------------------

  This Source Code Form is subject to the terms of the Mozilla Public
  License, v. 2.0. If a copy of the MPL was not distributed with this
  file, You can obtain one at http://mozilla.org/MPL/2.0/.

If it is not possible or desirable to put the notice in a particular
file, then You may include the notice in a location (such as a LICENSE
file in a relevant directory) where a recipient would be likely to look
for such a notice.

You may add additional accurate notices of copyright ownership.

Exhibit B - "Incompatible With Secondary Licenses" Notice
---------------------------------------------------------

  This Source Code Form is "Incompatible With Secondary Licenses", as
  defined by the Mozilla Public License, v. 2.0.
